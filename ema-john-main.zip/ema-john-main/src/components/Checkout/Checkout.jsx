import React from 'react';

const Checkout = () => {
    return (
        <div>
            <h1>My Checkout Page !! Welcome You Happy and Habi jabi</h1>
        </div>
    );
};

export default Checkout;