import React from 'react';

const Inventory = () => {
    return (
        <div>
            <h2>hallo welcome to my inventory pages!!!</h2>
        </div>
    );
};

export default Inventory;