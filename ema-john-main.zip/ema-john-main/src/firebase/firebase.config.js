// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCOKUKntG2Lh3xjuTuZA4DfGucwSidqH9g",
  authDomain: "ema-john-26c7e.firebaseapp.com",
  projectId: "ema-john-26c7e",
  storageBucket: "ema-john-26c7e.appspot.com",
  messagingSenderId: "996898985726",
  appId: "1:996898985726:web:524ddd899db7e1170937af"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export default app;